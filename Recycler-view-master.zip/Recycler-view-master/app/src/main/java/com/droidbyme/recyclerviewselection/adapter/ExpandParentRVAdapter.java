package com.droidbyme.recyclerviewselection.adapter;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.model.SectionsItem;

import java.util.List;

public class ExpandParentRVAdapter extends RecyclerView.Adapter<ExpandParentRVAdapter.ParentHolder> {

    private List<SectionsItem> listData;

    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<SectionsItem> listData) {
        this.listData = listData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ParentHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_expand_parent, parent, false);
        return new ParentHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ParentHolder holder, int position) {
        final SectionsItem planet = listData.get(position);
        holder.bind(planet);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.expandableView.getVisibility()==View.GONE){
                    TransitionManager.beginDelayedTransition(holder.clMain, new AutoTransition());
                    holder.expandableView.setVisibility(View.VISIBLE);
                    holder.arrowBtn.setBackgroundResource(R.drawable.ic_keyboard_arrow_up_black_24dp);

                    //Set child view Child RV
                    ExpandChildRVAdapter childRVAdapter = new ExpandChildRVAdapter();
                    holder.rvChild.setAdapter(childRVAdapter);
                    childRVAdapter.setData(planet.getFields());

                } else {
                    TransitionManager.beginDelayedTransition(holder.clMain, new AutoTransition());
                    holder.expandableView.setVisibility(View.GONE);
                    holder.arrowBtn.setBackgroundResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    static class ParentHolder extends RecyclerView.ViewHolder {

        private ConstraintLayout expandableView;
        private ConstraintLayout clMain;
        private Button arrowBtn;

        private TextView txtName;
        private TextView tvNumber;
        private TextView tvEmail;
        private RecyclerView rvChild;

        ParentHolder(View itemView) {
            super(itemView);
            expandableView = itemView.findViewById(R.id.expandableView);
            clMain = itemView.findViewById(R.id.clMain);
            arrowBtn = itemView.findViewById(R.id.arrowBtn);

            txtName = itemView.findViewById(R.id.name);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            tvEmail = itemView.findViewById(R.id.tvEmail);
            rvChild = itemView.findViewById(R.id.rvChild);
        }

        void bind(SectionsItem planet) {
            txtName.setText(planet.getKey());
            tvNumber.setText(planet.getNumber());
            tvEmail.setText(planet.getEmail());
        }
    }
}