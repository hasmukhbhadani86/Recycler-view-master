package com.droidbyme.recyclerviewselection.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.model.SectionsItem;

import java.util.List;

public class ExpandCardAdapter extends RecyclerView.Adapter<ExpandCardAdapter.PlanetHolder> {

    private Context context;
    private List<SectionsItem> planets;

    public ExpandCardAdapter(Context context, List<SectionsItem> planets) {
        this.context = context;
        this.planets = planets;
    }

    @NonNull
    @Override
    public PlanetHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_expand_card, parent, false);
        return new PlanetHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PlanetHolder holder, int position) {
        SectionsItem planet = planets.get(position);
        holder.bind(planet);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.expandableView.getVisibility()==View.GONE){
                    TransitionManager.beginDelayedTransition(holder.clMain, new AutoTransition());
                    holder.expandableView.setVisibility(View.VISIBLE);
                    holder.arrowBtn.setBackgroundResource(R.drawable.ic_keyboard_arrow_up_black_24dp);
                } else {
                    TransitionManager.beginDelayedTransition(holder.clMain, new AutoTransition());
                    holder.expandableView.setVisibility(View.GONE);
                    holder.arrowBtn.setBackgroundResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return planets.size();
    }

    class PlanetHolder extends RecyclerView.ViewHolder {

        private ConstraintLayout expandableView;
        private ConstraintLayout clMain;
        private Button arrowBtn;

        private TextView txtName;
        private TextView phoneNumber;
        private TextView email;

        PlanetHolder(View itemView) {
            super(itemView);
            expandableView = itemView.findViewById(R.id.expandableView);
            clMain = itemView.findViewById(R.id.clMain);
            arrowBtn = itemView.findViewById(R.id.arrowBtn);

            txtName = itemView.findViewById(R.id.name);
            phoneNumber = itemView.findViewById(R.id.phoneNumber);
            email = itemView.findViewById(R.id.email);
        }

        void bind(SectionsItem planet) {
            txtName.setText(planet.getKey());
            phoneNumber.setText(planet.getNumber());
            email.setText(planet.getEmail());
        }
    }
}