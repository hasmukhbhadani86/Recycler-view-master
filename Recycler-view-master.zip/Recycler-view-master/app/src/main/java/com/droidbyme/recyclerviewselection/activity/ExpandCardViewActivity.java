package com.droidbyme.recyclerviewselection.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.adapter.ExpandCardAdapter;
import com.droidbyme.recyclerviewselection.model.Response;
import com.google.gson.Gson;

public class ExpandCardViewActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ExpandCardAdapter adapter;
    private String strData ="{ \"data\": { \"sections\": [ { \"key\": \"Title - 1 \", \"number\": \"123456890\", \"eamil\": \"abc@gmail.com\" }, { \"key\": \"Title - 2\", \"number\": \"9876543210\", \"eamil\": \"xyz@gmail.com\" } ] } }";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exapndable_card);
        initView();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Expandable Card View");
    }

    private void initView() {
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Response obj = new Gson().fromJson(strData, Response.class);
        Log.e("TAG", "initView: "+obj.toString() );

        adapter = new ExpandCardAdapter(this, obj.getData().getSections());
        recyclerView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
