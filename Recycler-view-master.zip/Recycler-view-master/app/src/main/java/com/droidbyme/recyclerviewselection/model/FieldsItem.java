package com.droidbyme.recyclerviewselection.model;

public class FieldsItem{
	private boolean translatable;
	private boolean showNullable;
	private boolean privateModeApplicable;
	private boolean updateNullable;
	private String value;
	private String key;
	private int order;
	private String responseValuePrefix;

	public boolean isTranslatable(){
		return translatable;
	}

	public boolean isShowNullable(){
		return showNullable;
	}

	public boolean isPrivateModeApplicable(){
		return privateModeApplicable;
	}

	public boolean isUpdateNullable(){
		return updateNullable;
	}

	public String getValue(){
		return value;
	}

	public String getKey(){
		return key;
	}

	public int getOrder(){
		return order;
	}

	public String getResponseValuePrefix(){
		return responseValuePrefix;
	}
}
