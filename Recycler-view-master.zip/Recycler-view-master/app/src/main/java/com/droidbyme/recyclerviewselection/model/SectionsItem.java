package com.droidbyme.recyclerviewselection.model;

import java.util.List;

public class SectionsItem{
	private String number;
	private List<FieldsItem> fields;
	private String key;
	private String eamil;

	public String getNumber(){
		return number;
	}

	public List<FieldsItem> getFields(){
		return fields;
	}

	public String getKey(){
		return key;
	}

	public String getEmail(){
		return eamil;
	}
}