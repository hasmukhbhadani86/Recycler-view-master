package com.droidbyme.recyclerviewselection.model;

public class Meta{
	private String code;
	private String message;

	public String getCode(){
		return code;
	}

	public String getMessage(){
		return message;
	}
}
