package com.droidbyme.recyclerviewselection.model;

import java.util.List;

public class Response{
	private Data data;
	private Meta meta;

	public Data getData(){
		return data;
	}

	public Meta getMeta(){
		return meta;
	}

	public class Data{
		private List<SectionsItem> sections;

		public List<SectionsItem> getSections(){
			return sections;
		}
	}
}
