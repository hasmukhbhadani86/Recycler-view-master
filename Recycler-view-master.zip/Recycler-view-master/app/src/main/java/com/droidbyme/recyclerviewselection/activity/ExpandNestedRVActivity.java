package com.droidbyme.recyclerviewselection.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.adapter.ExpandParentRVAdapter;
import com.droidbyme.recyclerviewselection.model.Response;
import com.google.gson.Gson;

public class ExpandNestedRVActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ExpandParentRVAdapter adapter;
    private String strData ="{ \"data\": { \"sections\": [ { \"key\": \"Title 1\", \"number\": \"9090909090\", \"eamil\": \"abc@gmail.com\", \"fields\": [ { \"key\": \"Field 1\", \"value\": \"value1\" }, { \"key\": \"Field 2\", \"value\": \"Value 2\" } ] }, { \"key\": \"Title 2\", \"number\": \"9090909090\", \"eamil\": \"abc@gmail.com\", \"fields\": [ { \"key\": \"Field 2\", \"value\": \"Value 1\" }, { \"key\": \"Field 3\", \"value\": \"Value 2\" } ] } ] } }";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exapndable_nested);
        initView();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Expandable Nested RV");
    }

    private void initView() {
        recyclerView = (RecyclerView) findViewById(R.id.rvParent);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Response obj = new Gson().fromJson(strData, Response.class);
        Log.e("TAG", "initView: "+obj.toString() );

        adapter = new ExpandParentRVAdapter();
        recyclerView.setAdapter(adapter);

        adapter.setData(obj.getData().getSections());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
