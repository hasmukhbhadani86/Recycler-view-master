package com.droidbyme.recyclerviewselection.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.droidbyme.recyclerviewselection.R;
import com.droidbyme.recyclerviewselection.model.FieldsItem;

import java.util.List;

public class ExpandChildRVAdapter extends RecyclerView.Adapter<ExpandChildRVAdapter.ChildHolder> {

    private List<FieldsItem> listChildData;

    @SuppressLint("NotifyDataSetChanged")
    public void setData(List<FieldsItem> listChildData) {
        this.listChildData = listChildData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ChildHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_expand_child, parent, false);
        return new ChildHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ChildHolder holder, int position) {
        FieldsItem planet = listChildData.get(position);
        holder.bind(planet);
    }

    @Override
    public int getItemCount() {
        return listChildData.size();
    }

    static class ChildHolder extends RecyclerView.ViewHolder {

        private TextView txtName;

        ChildHolder(View itemView) {
            super(itemView);

            txtName = itemView.findViewById(R.id.name);
        }

        void bind(FieldsItem planet) {
            txtName.setText(planet.getKey());
        }
    }
}